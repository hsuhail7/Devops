#!/bin/bash

#This script will backup files from a particular directory as this is just for the Task purpose

#Since this is a Task so I am taking backup of only Day5 Directory and also keeping the backup in the same Directory

tar -cvpzf /home/ubuntu/Learning_Devops/Learning_Devops/Day5/Backup_Work/backup_of_Day5.tar.gz /home/ubuntu/Learning_Devops/Learning_Devops/Day5

